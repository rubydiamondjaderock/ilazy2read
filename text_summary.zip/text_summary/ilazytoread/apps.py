from django.apps import AppConfig


class CryptoConfig(AppConfig):
    name = 'ilazytoread'
