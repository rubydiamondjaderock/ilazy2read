from django.shortcuts import render, redirect

def home(request):
	return render(request, 'home.html')

def results(request):
	if request.method == 'POST':
		import requests
		import json
		web_url = request.POST['web_url']
		summary_request = requests.get("https://aylien-text.p.rapidapi.com/summarize?url=" +web_url+ "&sentences_number=5", headers={"X-RapidAPI-Key": "7c76678934msh46ddcf9c6c269a5p1014acjsn158b91092d85"})
		sum_result = json.loads(summary_request.content)
		if web_url:
			context = {'web_url' :web_url, 'sum_result': sum_result}
			return render(request, 'results.html', context)
		else:
			return redirect('home')

		# context = {'web_url' :web_url, 'sum_result': sum_result}
		# return render(request, 'results.html', context)
		
	else:
		notfound = "Choose any month and day from the dropdown above..."
		return render(request, 'results.html', {'notfound': notfound})